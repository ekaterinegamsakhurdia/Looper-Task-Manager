-- ============================================================
-- LOOPER TASKS — SEED DATA
-- 10 employees · 5 clients · 7 campaigns · 14 briefs · 48 tasks
-- Run AFTER 01_schema.sql
-- ============================================================

-- ── EMPLOYEES (10) ─────────────────────────────────────────
insert into employees (id, full_name, initials, email, role, department, avatar_color) values
  ('e1000000-0000-0000-0000-000000000001', 'Mariami Kvaratskhelia', 'MK', 'mariami@looperagency.ge',   'AM',             null,          '#A78BFA'),
  ('e1000000-0000-0000-0000-000000000002', 'Levan Beridze',         'LB', 'levan@looperagency.ge',     'Videographer',   'Production',  '#7C5CFC'),
  ('e1000000-0000-0000-0000-000000000003', 'Eka Gamsakhurdia',      'EG', 'eka@looperagency.ge',       'Designer',       'Design',      '#F472B6'),
  ('e1000000-0000-0000-0000-000000000004', 'Nika Kapanadze',        'NK', 'nika@looperagency.ge',      'Editor',         'Production',  '#34D399'),
  ('e1000000-0000-0000-0000-000000000005', 'Ana Kobakhidze',        'AK', 'ana@looperagency.ge',       'Designer',       'Design',      '#60A5FA'),
  ('e1000000-0000-0000-0000-000000000006', 'Giorgi Tsiklauri',      'GT', 'giorgi@looperagency.ge',    'Copywriter',     'Copy',        '#FB923C'),
  ('e1000000-0000-0000-0000-000000000007', 'Nino Mzhavanadze',      'NM', 'nino@looperagency.ge',      'Copywriter',     'Copy',        '#F9A8D4'),
  ('e1000000-0000-0000-0000-000000000008', 'Davit Lordkipanidze',   'DL', 'davit@looperagency.ge',     'Social Manager', 'DM',          '#38BDF8'),
  ('e1000000-0000-0000-0000-000000000009', 'Sopo Janelidze',        'SJ', 'sopo@looperagency.ge',      'Social Manager', 'DM',          '#818CF8'),
  ('e1000000-0000-0000-0000-000000000010', 'Tornike Abuladze',      'TA', 'tornike@looperagency.ge',   'Director',       null,          '#FCD34D');

-- ── CLIENTS (5) ────────────────────────────────────────────
insert into clients (id, name, am_owner_id, status, industry, client_tier, platforms, contact_email) values
  ('c1000000-0000-0000-0000-000000000001', 'ESB Group',        'e1000000-0000-0000-0000-000000000001', 'Active', 'Real Estate',   'Gold',   array['Instagram','Facebook','YouTube'],       'marketing@esbgroup.ge'),
  ('c1000000-0000-0000-0000-000000000002', 'Photomate',        'e1000000-0000-0000-0000-000000000001', 'Active', 'Technology',    'Gold',   array['Instagram','TikTok','App Store'],       'brand@photomate.app'),
  ('c1000000-0000-0000-0000-000000000003', 'Black Sea Spirits','e1000000-0000-0000-0000-000000000001', 'Active', 'Beverage',      'Silver', array['Instagram','Facebook'],                 'hello@blackseaspirits.ge'),
  ('c1000000-0000-0000-0000-000000000004', 'Silk Road Hotels', 'e1000000-0000-0000-0000-000000000001', 'Active', 'Hospitality',   'Silver', array['Instagram','Facebook','Booking.com'],   'pr@silkroadhotels.ge'),
  ('c1000000-0000-0000-0000-000000000005', 'Bank of Georgia',  'e1000000-0000-0000-0000-000000000001', 'Active', 'Finance',       'Gold',   array['Instagram','Facebook','YouTube','OOH'], 'agency@bog.ge');

-- ── CAMPAIGNS (7) ──────────────────────────────────────────
insert into ad_campaigns (id, name, client_id, am_id, status, start_date, end_date) values
  ('a1000000-0000-0000-0000-000000000001', 'ESB Summer 2026',         'c1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'Active',    '2026-07-01', '2026-09-30'),
  ('a1000000-0000-0000-0000-000000000002', 'ESB Q4 Brand Push',       'c1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'Active',    '2026-10-01', '2026-12-31'),
  ('a1000000-0000-0000-0000-000000000003', 'Photomate App Launch',    'c1000000-0000-0000-0000-000000000002', 'e1000000-0000-0000-0000-000000000001', 'Active',    '2026-10-15', '2026-11-30'),
  ('a1000000-0000-0000-0000-000000000004', 'Black Sea Rebrand',       'c1000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000001', 'Active',    '2026-09-01', '2026-12-31'),
  ('a1000000-0000-0000-0000-000000000005', 'Silk Road Winter Season', 'c1000000-0000-0000-0000-000000000004', 'e1000000-0000-0000-0000-000000000001', 'Active',    '2026-11-01', '2027-01-31'),
  ('a1000000-0000-0000-0000-000000000006', 'BoG Product Q4',          'c1000000-0000-0000-0000-000000000005', 'e1000000-0000-0000-0000-000000000001', 'Active',    '2026-10-01', '2026-12-31'),
  ('a1000000-0000-0000-0000-000000000007', 'ESB Summer 2025 (Done)',  'c1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'Completed', '2025-07-01', '2025-09-30');

-- ── BRIEFS (14) ────────────────────────────────────────────
insert into briefs (id, title, brief_type, status, client_id, campaign_id, am_owner_id, copywriter_id, copy_deadline, committed_task_count, created_by) values
  -- ESB Summer
  ('b1000000-0000-0000-0000-000000000001', 'ESB | Summer Reels Package',      'Video',      'Production', 'c1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-10-28', 6, 'e1000000-0000-0000-0000-000000000001'),
  -- ESB Q4
  ('b1000000-0000-0000-0000-000000000002', 'ESB | Q4 Digital Billboard',      'Post/Design','Design',     'c1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000002', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', '2026-10-30', 4, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000003', 'ESB | Outdoor Campaign Nov',      'Campaign',   'Copy',       'c1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000002', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', '2026-11-05', 5, 'e1000000-0000-0000-0000-000000000001'),
  -- Photomate
  ('b1000000-0000-0000-0000-000000000004', 'Photomate | Motion Package',      'Video',      'Production', 'c1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-11-09', 3, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000005', 'Photomate | Social Launch Stories','Story',     'Design',     'c1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-11-06', 4, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000006', 'Photomate | App Store Assets',    'Post/Design','Production', 'c1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000001', null,                                   null,          2, 'e1000000-0000-0000-0000-000000000001'),
  -- Black Sea Spirits
  ('b1000000-0000-0000-0000-000000000007', 'Black Sea | Label Redesign',      'Post/Design','Design',     'c1000000-0000-0000-0000-000000000003', 'a1000000-0000-0000-0000-000000000004', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', '2026-10-20', 3, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000008', 'Black Sea | Brand Film',          'Video',      'Production', 'c1000000-0000-0000-0000-000000000003', 'a1000000-0000-0000-0000-000000000004', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-10-25', 4, 'e1000000-0000-0000-0000-000000000001'),
  -- Silk Road
  ('b1000000-0000-0000-0000-000000000009', 'Silk Road | Winter Social Pack',  'Campaign',   'Copy',       'c1000000-0000-0000-0000-000000000004', 'a1000000-0000-0000-0000-000000000005', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-11-10', 6, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000010', 'Silk Road | Lobby Promo Video',   'Video',      'Done',       'c1000000-0000-0000-0000-000000000004', 'a1000000-0000-0000-0000-000000000005', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', '2026-10-15', 2, 'e1000000-0000-0000-0000-000000000001'),
  -- Bank of Georgia
  ('b1000000-0000-0000-0000-000000000011', 'BoG | Product Explainer Video',   'Video',      'Production', 'c1000000-0000-0000-0000-000000000005', 'a1000000-0000-0000-0000-000000000006', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-10-28', 2, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000012', 'BoG | Q4 OOH Campaign',           'Campaign',   'Design',     'c1000000-0000-0000-0000-000000000005', 'a1000000-0000-0000-0000-000000000006', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', '2026-11-01', 5, 'e1000000-0000-0000-0000-000000000001'),
  -- DM/Social
  ('b1000000-0000-0000-0000-000000000013', 'ESB | Instagram November Plan',   'Post/Design','Copy',       'c1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000002', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', '2026-11-03', 8, 'e1000000-0000-0000-0000-000000000001'),
  ('b1000000-0000-0000-0000-000000000014', 'Photomate | TikTok Launch Series','Story',      'Copy',       'c1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000007', '2026-11-07', 5, 'e1000000-0000-0000-0000-000000000001');

-- ── TASKS (48) ─────────────────────────────────────────────
-- Brief #1 — ESB Summer Reels (committed: 6)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, client_revision_count, bounce_client, created_by) values
('ESB Summer — Hero Reel 60s',          'b1000000-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Delivered',       'P1','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-08-20','2026-08-25',0,false,'e1000000-0000-0000-0000-000000000001'),
('ESB Summer — Cut-down 30s',           'b1000000-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Delivered',       'P1','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-08-22','2026-08-25',0,false,'e1000000-0000-0000-0000-000000000001'),
('ESB Summer — Cut-down 15s',           'b1000000-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Delivered',       'P2','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000004'::uuid],'2026-08-22','2026-08-25',0,false,'e1000000-0000-0000-0000-000000000001'),
('ESB Summer — Story Vertical',         'b1000000-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Delivered',       'P2','Story','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-08-23','2026-08-27',0,false,'e1000000-0000-0000-0000-000000000001'),
('ESB Summer — Behind the Scenes',      'b1000000-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Delivered',       'P3','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-08-25','2026-08-30',0,false,'e1000000-0000-0000-0000-000000000001'),
('ESB Summer — Teaser Reel',            'b1000000-0000-0000-0000-000000000001','a1000000-0000-0000-0000-000000000001','Delivered',       'P2','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000004'::uuid],'2026-08-18','2026-08-20',0,false,'e1000000-0000-0000-0000-000000000001');

-- Brief #2 — ESB Q4 Billboard (committed: 4)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('ESB Q4 — Billboard 3x6m Landscape',   'b1000000-0000-0000-0000-000000000002','a1000000-0000-0000-0000-000000000002','Designing',       'P2','OOH','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-08','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('ESB Q4 — Digital Screen 16:9',        'b1000000-0000-0000-0000-000000000002','a1000000-0000-0000-0000-000000000002','Designing',       'P2','OOH','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-08','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('ESB Q4 — Lightbox Portrait',          'b1000000-0000-0000-0000-000000000002','a1000000-0000-0000-0000-000000000002','Not started',     'P3','OOH','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-12','2026-11-20','e1000000-0000-0000-0000-000000000001'),
('ESB Q4 — Social Adaptation Set',      'b1000000-0000-0000-0000-000000000002','a1000000-0000-0000-0000-000000000002','Not started',     'P3','Post/Design','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-15','2026-11-20','e1000000-0000-0000-0000-000000000001');

-- Brief #3 — ESB Outdoor Nov (committed: 5)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('ESB Nov — Campaign Key Visual',       'b1000000-0000-0000-0000-000000000003','a1000000-0000-0000-0000-000000000002','Internal Review', 'P1','Photo','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-07','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('ESB Nov — Location Scout & Shoot',    'b1000000-0000-0000-0000-000000000003','a1000000-0000-0000-0000-000000000002','Shoot Readiness', 'P1','Photo','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid, 'e1000000-0000-0000-0000-000000000004'::uuid],'2026-11-06','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('ESB Nov — Retouching & Grading',      'b1000000-0000-0000-0000-000000000003','a1000000-0000-0000-0000-000000000002','Not started',     'P2','Photo','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000004'::uuid],'2026-11-10','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('ESB Nov — Copywriting (OOH)',         'b1000000-0000-0000-0000-000000000003','a1000000-0000-0000-0000-000000000002','Not started',     'P2','Copy','Copy','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000006'::uuid],'2026-11-05','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('ESB Nov — Final Production Files',    'b1000000-0000-0000-0000-000000000003','a1000000-0000-0000-0000-000000000002','Not started',     'P2','OOH','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-13','2026-11-15','e1000000-0000-0000-0000-000000000001');

-- Brief #4 — Photomate Motion (committed: 3)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('Photomate — Hero Animation 15s',      'b1000000-0000-0000-0000-000000000004','a1000000-0000-0000-0000-000000000003','Internal Review', 'P1','Animation','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-07','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate — Motion Graphics Pkg',     'b1000000-0000-0000-0000-000000000004','a1000000-0000-0000-0000-000000000003','Editing',         'P2','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid, 'e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-10','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate — Loading Screen Loop',     'b1000000-0000-0000-0000-000000000004','a1000000-0000-0000-0000-000000000003','Motion',          'P1','Animation','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-07','2026-11-13','e1000000-0000-0000-0000-000000000001');

-- Brief #5 — Photomate Stories (committed: 4)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('Photomate — Launch Day Story Set',    'b1000000-0000-0000-0000-000000000005','a1000000-0000-0000-0000-000000000003','Internal Review', 'P1','Story','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-08','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate — Countdown Stories x5',   'b1000000-0000-0000-0000-000000000005','a1000000-0000-0000-0000-000000000003','Designing',       'P2','Story','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-08','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate — Feature Highlight Set',  'b1000000-0000-0000-0000-000000000005','a1000000-0000-0000-0000-000000000003','Not started',     'P3','Story','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-10','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate — Story Copy Pack',        'b1000000-0000-0000-0000-000000000005','a1000000-0000-0000-0000-000000000003','Not started',     'P2','Copy','Copy','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000007'::uuid],'2026-11-06','2026-11-13','e1000000-0000-0000-0000-000000000001');

-- Brief #6 — Photomate App Store (committed: 2)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('Photomate — App Store Screenshots',  'b1000000-0000-0000-0000-000000000006','a1000000-0000-0000-0000-000000000003','Designing',       'P1','Post/Design','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-09','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate — Feature Graphic Banner', 'b1000000-0000-0000-0000-000000000006','a1000000-0000-0000-0000-000000000003','Not started',     'P2','Post/Design','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-10','2026-11-13','e1000000-0000-0000-0000-000000000001');

-- Brief #7 — Black Sea Label (committed: 3)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, internal_revision_count, bounce_internal, created_by) values
('Black Sea — Vodka Label Design',     'b1000000-0000-0000-0000-000000000007','a1000000-0000-0000-0000-000000000004','Bounced',         'P2','Print','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-09','2026-11-20',1,true,'e1000000-0000-0000-0000-000000000001'),
('Black Sea — Whisky Series Labels',   'b1000000-0000-0000-0000-000000000007','a1000000-0000-0000-0000-000000000004','Designing',       'P2','Print','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-12','2026-11-20',0,false,'e1000000-0000-0000-0000-000000000001'),
('Black Sea — Packaging Dieline',      'b1000000-0000-0000-0000-000000000007','a1000000-0000-0000-0000-000000000004','Not started',     'P3','Print','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-15','2026-11-20',0,false,'e1000000-0000-0000-0000-000000000001');

-- Brief #8 — Black Sea Film (committed: 4)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, shoot_date, internal_deadline, launch_date, created_by) values
('Black Sea — Brand Film 90s',         'b1000000-0000-0000-0000-000000000008','a1000000-0000-0000-0000-000000000004','Editing',         'P1','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid, 'e1000000-0000-0000-0000-000000000004'::uuid],'2026-10-28','2026-11-04','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('Black Sea — Behind the Brand',       'b1000000-0000-0000-0000-000000000008','a1000000-0000-0000-0000-000000000004','Not started',     'P2','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-10','2026-11-15',null,'e1000000-0000-0000-0000-000000000001'),
('Black Sea — Distillery Shoot',       'b1000000-0000-0000-0000-000000000008','a1000000-0000-0000-0000-000000000004','Filming',         'P1','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid, 'e1000000-0000-0000-0000-000000000010'::uuid],'2026-10-30','2026-11-01','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('Black Sea — Colour Grade & Sound',   'b1000000-0000-0000-0000-000000000008','a1000000-0000-0000-0000-000000000004','Not started',     'P2','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000004'::uuid],'2026-11-12','2026-11-15',null,'e1000000-0000-0000-0000-000000000001');

-- Brief #9 — Silk Road Winter (committed: 6)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('Silk Road — Winter Feed x12',        'b1000000-0000-0000-0000-000000000009','a1000000-0000-0000-0000-000000000005','Not started',     'P2','Post/Design','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-20','2026-11-25','e1000000-0000-0000-0000-000000000001'),
('Silk Road — New Year Stories',       'b1000000-0000-0000-0000-000000000009','a1000000-0000-0000-0000-000000000005','Not started',     'P2','Story','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-25','2026-12-01','e1000000-0000-0000-0000-000000000001'),
('Silk Road — Season Campaign Reel',   'b1000000-0000-0000-0000-000000000009','a1000000-0000-0000-0000-000000000005','Not started',     'P1','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-22','2026-11-25','e1000000-0000-0000-0000-000000000001'),
('Silk Road — Winter Copy Pack',       'b1000000-0000-0000-0000-000000000009','a1000000-0000-0000-0000-000000000005','Not started',     'P3','Copy','Copy','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000007'::uuid],'2026-11-10','2026-11-25','e1000000-0000-0000-0000-000000000001');

-- Brief #10 — Silk Road Lobby Video (committed: 2)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('Silk Road — Lobby Promo 3min',       'b1000000-0000-0000-0000-000000000010','a1000000-0000-0000-0000-000000000005','Sent to client',  'P2','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000004'::uuid],'2026-11-01','2026-11-10','e1000000-0000-0000-0000-000000000001'),
('Silk Road — Restaurant Reel',        'b1000000-0000-0000-0000-000000000010','a1000000-0000-0000-0000-000000000005','Approved',        'P2','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-10-28','2026-11-05','e1000000-0000-0000-0000-000000000001');

-- Brief #11 — BoG Explainer (committed: 2)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, client_revision_count, bounce_client, created_by) values
('BoG — Product Explainer 90s',        'b1000000-0000-0000-0000-000000000011','a1000000-0000-0000-0000-000000000006','Bounced',         'P1','Video','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-04','2026-11-10',2,true,'e1000000-0000-0000-0000-000000000001'),
('BoG — Animated Infographic',         'b1000000-0000-0000-0000-000000000011','a1000000-0000-0000-0000-000000000006','Internal Review', 'P1','Animation','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-05','2026-11-10',0,false,'e1000000-0000-0000-0000-000000000001');

-- Brief #12 — BoG OOH (committed: 5)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('BoG — Metro OOH Key Visual',         'b1000000-0000-0000-0000-000000000012','a1000000-0000-0000-0000-000000000006','Internal Review', 'P1','OOH','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000005'::uuid],'2026-11-07','2026-11-15','e1000000-0000-0000-0000-000000000001'),
('BoG — Branch Window Vinyl',          'b1000000-0000-0000-0000-000000000012','a1000000-0000-0000-0000-000000000006','Not started',     'P2','Print','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-12','2026-11-20','e1000000-0000-0000-0000-000000000001'),
('BoG — Digital Display Animations',   'b1000000-0000-0000-0000-000000000012','a1000000-0000-0000-0000-000000000006','Not started',     'P2','Animation','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-14','2026-11-20','e1000000-0000-0000-0000-000000000001');

-- Brief #13 — ESB Instagram Plan (committed: 8, social / DM)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('ESB IG Nov — Week 1 Post Pack',      'b1000000-0000-0000-0000-000000000013','a1000000-0000-0000-0000-000000000002','Sent to client',  'P2','Post/Design','DM','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000008'::uuid],'2026-11-03','2026-11-07','e1000000-0000-0000-0000-000000000001'),
('ESB IG Nov — Week 2 Post Pack',      'b1000000-0000-0000-0000-000000000013','a1000000-0000-0000-0000-000000000002','Not started',     'P2','Post/Design','DM','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000008'::uuid],'2026-11-10','2026-11-14','e1000000-0000-0000-0000-000000000001'),
('ESB IG Nov — Week 3 Post Pack',      'b1000000-0000-0000-0000-000000000013','a1000000-0000-0000-0000-000000000002','Not started',     'P3','Post/Design','DM','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000009'::uuid],'2026-11-17','2026-11-21','e1000000-0000-0000-0000-000000000001'),
('ESB IG Nov — Caption Copy x12',      'b1000000-0000-0000-0000-000000000013','a1000000-0000-0000-0000-000000000002','Not started',     'P2','Copy','Copy','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000006'::uuid],'2026-11-03','2026-11-07','e1000000-0000-0000-0000-000000000001'),
('ESB IG Nov — Reel x2',              'b1000000-0000-0000-0000-000000000013','a1000000-0000-0000-0000-000000000002','Not started',     'P2','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-15','2026-11-20','e1000000-0000-0000-0000-000000000001');

-- Brief #14 — Photomate TikTok (committed: 5)
insert into tasks (title, brief_id, campaign_id, stage, priority, task_type, department, am_id, assigned_to, internal_deadline, launch_date, created_by) values
('Photomate TT — Launch Hero TikTok',  'b1000000-0000-0000-0000-000000000014','a1000000-0000-0000-0000-000000000003','Designing',       'P1','Reel','Design','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000003'::uuid],'2026-11-09','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate TT — Feature Series x3',   'b1000000-0000-0000-0000-000000000014','a1000000-0000-0000-0000-000000000003','Not started',     'P2','Reel','Production','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000002'::uuid],'2026-11-11','2026-11-13','e1000000-0000-0000-0000-000000000001'),
('Photomate TT — Script & Captions',   'b1000000-0000-0000-0000-000000000014','a1000000-0000-0000-0000-000000000003','Not started',     'P2','Copy','Copy','e1000000-0000-0000-0000-000000000001',array['e1000000-0000-0000-0000-000000000007'::uuid],'2026-11-07','2026-11-13','e1000000-0000-0000-0000-000000000001');

-- ── SAMPLE COMMENTS ────────────────────────────────────────
insert into task_comments (task_id, author_id, body)
select t.id, 'e1000000-0000-0000-0000-000000000007', 'Copy delivered. Hero VO runs exactly 40 words — "Capture everything. Instantly." confirmed as final tagline.'
from tasks t where t.title = 'Photomate — Motion Graphics Pkg';

insert into task_comments (task_id, author_id, body)
select t.id, 'e1000000-0000-0000-0000-000000000002', 'Starting edit now. Footage from drive synced.'
from tasks t where t.title = 'Photomate — Motion Graphics Pkg';

insert into task_comments (task_id, author_id, body)
select t.id, 'e1000000-0000-0000-0000-000000000001', 'Client wants revision on colour grading — too warm. Needs to match brand palette sheet (cooler, more neutral).'
from tasks t where t.title = 'BoG — Product Explainer 90s';

insert into task_comments (task_id, author_id, body)
select t.id, 'e1000000-0000-0000-0000-000000000004', 'Graded and re-exported. Sending v3 for internal check before back to client.'
from tasks t where t.title = 'BoG — Product Explainer 90s';

-- ── REVISION LOG ENTRIES ───────────────────────────────────
insert into revision_log (task_id, type, note, logged_by)
select t.id, 'client', 'Client: colour grading too warm, needs to match brand guide cool tones', 'e1000000-0000-0000-0000-000000000001'
from tasks t where t.title = 'BoG — Product Explainer 90s';

insert into revision_log (task_id, type, note, logged_by)
select t.id, 'client', 'Client: CTA text too small, requested bigger font and different placement', 'e1000000-0000-0000-0000-000000000001'
from tasks t where t.title = 'BoG — Product Explainer 90s';

insert into revision_log (task_id, type, note, logged_by)
select t.id, 'internal', 'Director: label typeface needs to change — too decorative, not premium enough', 'e1000000-0000-0000-0000-000000000010'
from tasks t where t.title = 'Black Sea — Vodka Label Design';
