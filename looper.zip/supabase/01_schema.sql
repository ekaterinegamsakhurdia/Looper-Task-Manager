-- ============================================================
-- LOOPER TASKS — DATABASE SCHEMA
-- Run this in Supabase SQL editor (Dashboard → SQL Editor)
-- Uses the same Supabase project as Looper Attendance
-- ============================================================

-- ── EXTENSIONS ─────────────────────────────────────────────
create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm"; -- for fast text search

-- ── ENUMS ──────────────────────────────────────────────────
create type task_stage as enum (
  'Not started', 'Editing', 'Motion', 'Designing',
  'Bounced', 'Internal Review', 'Sent to client',
  'Approved', 'Delivered', 'Archive',
  'Shoot Readiness', 'Filming'
);

create type task_priority as enum ('P1', 'P2', 'P3', 'P4');

create type task_type as enum (
  'Video', 'Post/Design', 'Story', 'Reel',
  'Animation', 'Copy', 'Photo', 'OOH', 'Print'
);

create type department as enum ('Design', 'Production', 'DM', 'Copy');

create type brief_type as enum ('Video', 'Post/Design', 'Story', 'Campaign');

create type brief_status as enum (
  'Copy', 'Design', 'Production', 'Done', 'Archived'
);

create type client_tier as enum ('Gold', 'Silver', 'Bronze');

create type client_status as enum ('Active', 'Inactive', 'Prospect');

create type campaign_status as enum ('Active', 'Paused', 'Completed', 'Draft');

create type employee_role as enum (
  'AM', 'Designer', 'Videographer', 'Copywriter',
  'Editor', 'Social Manager', 'Director', 'Admin'
);

-- ── EMPLOYEES ──────────────────────────────────────────────
-- Links to auth.users via user_id (nullable for pre-created accounts)
create table employees (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid references auth.users(id) on delete set null,
  emp_id        serial unique,                        -- display: EMP-001
  full_name     text not null,
  initials      char(2) not null,
  email         text unique not null,
  role          employee_role not null,
  department    department,
  avatar_color  text default '#7C5CFC',              -- hex for UI avatar
  is_active     boolean default true,
  created_at    timestamptz default now()
);

-- ── CLIENTS ────────────────────────────────────────────────
create table clients (
  id             uuid primary key default uuid_generate_v4(),
  client_id      serial unique,                       -- display: CLT-001
  name           text not null,
  logo_url       text,
  am_owner_id    uuid references employees(id),
  status         client_status default 'Active',
  industry       text,
  client_tier    client_tier default 'Silver',
  platforms      text[] default '{}',
  contact_email  text,
  created_at     timestamptz default now()
);

-- ── AD CAMPAIGNS ───────────────────────────────────────────
create table ad_campaigns (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  client_id   uuid not null references clients(id) on delete cascade,
  am_id       uuid references employees(id),
  status      campaign_status default 'Active',
  start_date  date,
  end_date    date,
  created_at  timestamptz default now()
);

-- ── BRIEFS ─────────────────────────────────────────────────
create table briefs (
  id                    uuid primary key default uuid_generate_v4(),
  brief_id              serial unique,               -- display: #1001
  title                 text not null,
  body                  jsonb,                       -- Tiptap JSON
  brief_type            brief_type not null,
  status                brief_status default 'Copy',
  client_id             uuid not null references clients(id),
  campaign_id           uuid references ad_campaigns(id),
  am_owner_id           uuid references employees(id),
  copywriter_id         uuid references employees(id),
  copy_deadline         date,
  committed_task_count  int default 0,              -- set by AM when creating brief
  -- actual_task_count: use COUNT(*) from tasks where brief_id = this.id
  archive_log           jsonb default '[]',
  archived_at           timestamptz,
  created_at            timestamptz default now(),
  created_by            uuid references employees(id)
);

-- ── TASKS ──────────────────────────────────────────────────
create table tasks (
  id                      uuid primary key default uuid_generate_v4(),
  task_id                 serial unique,             -- display: #937
  title                   text not null,
  body                    jsonb,                     -- Tiptap JSON
  brief_id                uuid references briefs(id),
  campaign_id             uuid references ad_campaigns(id),
  parent_task_id          uuid references tasks(id), -- child tasks (self-ref)
  stage                   task_stage default 'Not started',
  priority                task_priority default 'P2',
  task_type               task_type,
  department              department,
  place                   text,                      -- location note
  am_id                   uuid references employees(id),
  assigned_to             uuid[] default '{}',       -- multi-person
  shoot_date              date,
  internal_deadline       date,
  launch_date             date,
  internal_revision_count int default 0,
  client_revision_count   int default 0,
  bounce_internal         boolean default false,
  bounce_client           boolean default false,
  archived_at             timestamptz,
  created_at              timestamptz default now(),
  created_by              uuid references employees(id)
);

-- ── TASK COMMENTS ──────────────────────────────────────────
create table task_comments (
  id          uuid primary key default uuid_generate_v4(),
  task_id     uuid not null references tasks(id) on delete cascade,
  author_id   uuid not null references employees(id),
  body        text not null,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

-- ── TASK ATTACHMENTS ───────────────────────────────────────
create table task_attachments (
  id           uuid primary key default uuid_generate_v4(),
  task_id      uuid not null references tasks(id) on delete cascade,
  name         text not null,
  url          text not null,
  mime_type    text,
  size_bytes   int,
  uploaded_by  uuid references employees(id),
  created_at   timestamptz default now()
);

-- ── REVISION LOG ───────────────────────────────────────────
create table revision_log (
  id          uuid primary key default uuid_generate_v4(),
  task_id     uuid not null references tasks(id) on delete cascade,
  type        text not null check (type in ('internal', 'client')),
  note        text,
  logged_by   uuid references employees(id),
  created_at  timestamptz default now()
);

-- ── INDEXES ────────────────────────────────────────────────
create index idx_tasks_stage       on tasks(stage);
create index idx_tasks_priority    on tasks(priority);
create index idx_tasks_department  on tasks(department);
create index idx_tasks_brief_id    on tasks(brief_id);
create index idx_tasks_campaign_id on tasks(campaign_id);
create index idx_tasks_am_id       on tasks(am_id);
create index idx_tasks_assigned    on tasks using gin(assigned_to);
create index idx_tasks_launch_date on tasks(launch_date);
create index idx_tasks_title_trgm  on tasks using gin(title gin_trgm_ops);
create index idx_briefs_client_id  on briefs(client_id);
create index idx_briefs_status     on briefs(status);
create index idx_comments_task_id  on task_comments(task_id);

-- ── REALTIME ───────────────────────────────────────────────
alter publication supabase_realtime add table tasks;
alter publication supabase_realtime add table task_comments;
alter publication supabase_realtime add table briefs;

-- ── RLS ────────────────────────────────────────────────────
-- Simple org-wide policy: all authenticated users can read everything.
-- Writes are open for now (add per-role policies in Phase 2).
alter table employees        enable row level security;
alter table clients          enable row level security;
alter table ad_campaigns     enable row level security;
alter table briefs           enable row level security;
alter table tasks            enable row level security;
alter table task_comments    enable row level security;
alter table task_attachments enable row level security;
alter table revision_log     enable row level security;

-- Full access for authenticated users (tighten later)
create policy "auth_all" on employees        for all to authenticated using (true) with check (true);
create policy "auth_all" on clients          for all to authenticated using (true) with check (true);
create policy "auth_all" on ad_campaigns     for all to authenticated using (true) with check (true);
create policy "auth_all" on briefs           for all to authenticated using (true) with check (true);
create policy "auth_all" on tasks            for all to authenticated using (true) with check (true);
create policy "auth_all" on task_comments    for all to authenticated using (true) with check (true);
create policy "auth_all" on task_attachments for all to authenticated using (true) with check (true);
create policy "auth_all" on revision_log     for all to authenticated using (true) with check (true);

-- ── HELPER VIEWS ───────────────────────────────────────────
-- tasks with actual count per brief (used for count_check UI)
create view brief_task_counts as
  select
    b.id                    as brief_id,
    b.brief_id              as brief_display_id,
    b.title,
    b.committed_task_count,
    count(t.id)::int        as actual_task_count,
    (b.committed_task_count = count(t.id)::int) as count_match
  from briefs b
  left join tasks t on t.brief_id = b.id and t.archived_at is null
  group by b.id;

-- tasks with joined names for display
create view tasks_full as
  select
    t.*,
    b.title                as brief_title,
    b.brief_id             as brief_display_id,
    cl.name                as client_name,
    ac.name                as campaign_name,
    am.full_name           as am_name,
    am.initials            as am_initials,
    am.avatar_color        as am_color
  from tasks t
  left join briefs b        on b.id = t.brief_id
  left join clients cl      on cl.id = b.client_id
  left join ad_campaigns ac on ac.id = t.campaign_id
  left join employees am    on am.id = t.am_id;
