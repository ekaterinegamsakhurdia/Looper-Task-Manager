import { useState, useEffect, useCallback } from 'react'
import supabase from '../lib/supabase'
import { fetchTasks, updateTaskStage } from '../lib/queries'

export function useTasks(filters = {}) {
  const [tasks, setTasks]     = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState(null)

  const load = useCallback(async () => {
    try {
      setLoading(true)
      const data = await fetchTasks(filters)
      setTasks(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [JSON.stringify(filters)])

  useEffect(() => { load() }, [load])

  // Realtime subscription
  useEffect(() => {
    const sub = supabase
      .channel('tasks-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, () => load())
      .subscribe()
    return () => supabase.removeChannel(sub)
  }, [load])

  const moveTask = async (id, stage) => {
    // Optimistic update
    setTasks(prev => prev.map(t => t.id === id ? { ...t, stage } : t))
    try { await updateTaskStage(id, stage) }
    catch (e) { load() } // rollback on error
  }

  return { tasks, loading, error, reload: load, moveTask }
}

export default useTasks
