import { useState, useEffect } from 'react'
import { X, MessageCircle, Send, RotateCcw, ChevronDown } from 'lucide-react'
import PriorityChip from './PriorityChip'
import StageBadge from './StageBadge'
import Avatar from './Avatar'
import BRAND from '../config/brand'
import { fetchComments, createComment, logBounce, updateTask } from '../lib/queries'

function Field({ label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)',
        letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</span>
      <div style={{ fontSize: 13, color: 'var(--text-primary)' }}>{children}</div>
    </div>
  )
}

export function TaskDrawer({ task, onClose, currentUser, onUpdated }) {
  const [comments, setComments]     = useState([])
  const [newComment, setNewComment] = useState('')
  const [loadingComments, setLC]    = useState(true)
  const [saving, setSaving]         = useState(false)
  const [stageOpen, setStageOpen]   = useState(false)
  const [priorityOpen, setPrioOpen] = useState(false)

  useEffect(() => {
    if (!task) return
    setLC(true)
    fetchComments(task.id).then(d => { setComments(d); setLC(false) })
  }, [task?.id])

  // Close on Escape
  useEffect(() => {
    const h = e => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])

  if (!task) return null

  const submitComment = async () => {
    if (!newComment.trim() || !currentUser) return
    setSaving(true)
    const c = await createComment(task.id, currentUser.id, newComment.trim())
    setComments(prev => [...prev, c])
    setNewComment('')
    setSaving(false)
  }

  const handleStageChange = async stage => {
    setStageOpen(false)
    await updateTask(task.id, { stage })
    onUpdated?.({ ...task, stage })
  }

  const handlePriorityChange = async priority => {
    setPrioOpen(false)
    await updateTask(task.id, { priority })
    onUpdated?.({ ...task, priority })
  }

  const handleBounce = async (type) => {
    if (!currentUser) return
    const note = window.prompt(`Reason for ${type} bounce (optional):`)
    if (note === null) return // cancelled
    await logBounce(task.id, type, note, currentUser.id)
    onUpdated?.({ ...task, stage: 'Bounced' })
  }

  const fmt = d => d ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.5)',
          zIndex: 40,
        }}
      />
      {/* Drawer */}
      <div style={{
        position: 'fixed', top: 0, right: 0, bottom: 0,
        width: 'min(var(--drawer-w), 100vw)',
        background: 'var(--surface-1)',
        borderLeft: '1px solid var(--border)',
        zIndex: 50,
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'flex-start', gap: 12,
          padding: '18px 20px',
          borderBottom: '1px solid var(--border)',
          background: 'var(--surface-2)',
        }}>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <PriorityChip priority={task.priority} />
              <StageBadge stage={task.stage} />
              {task.client_name && (
                <span style={{ fontSize: 11, color: 'var(--text-muted)', alignSelf: 'center' }}>
                  {task.client_name}
                </span>
              )}
            </div>
            <h2 style={{ fontSize: 16, fontWeight: 600, lineHeight: 1.4, color: 'var(--text-primary)' }}>
              {task.title}
            </h2>
            <span style={{
              fontSize: 11, fontFamily: 'var(--font-mono)',
              color: 'var(--text-muted)',
            }}>
              #{task.task_id} · {task.task_type ?? '—'} · {task.department ?? '—'}
            </span>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--text-muted)', padding: 4, borderRadius: 6,
              display: 'flex', alignItems: 'center',
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div style={{
          flex: 1, overflowY: 'auto',
          padding: '20px',
          display: 'flex', flexDirection: 'column', gap: 20,
        }}>
          {/* Quick actions */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {/* Stage picker */}
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setStageOpen(o => !o)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '6px 12px', borderRadius: 'var(--r-sm)',
                  background: 'var(--surface-3)', border: '1px solid var(--border)',
                  color: 'var(--text-primary)', cursor: 'pointer', fontSize: 12,
                }}
              >
                Move stage <ChevronDown size={13} />
              </button>
              {stageOpen && (
                <div style={{
                  position: 'absolute', top: '110%', left: 0, zIndex: 10,
                  background: 'var(--surface-2)', border: '1px solid var(--border)',
                  borderRadius: 'var(--r-md)', overflow: 'hidden', minWidth: 180,
                  boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
                }}>
                  {BRAND.stages.map(s => (
                    <button
                      key={s.id}
                      onClick={() => handleStageChange(s.id)}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 8,
                        width: '100%', padding: '8px 12px',
                        background: task.stage === s.id ? 'var(--violet-dim)' : 'none',
                        border: 'none', cursor: 'pointer',
                        color: 'var(--text-primary)', fontSize: 12, textAlign: 'left',
                      }}
                    >
                      <span style={{ width: 8, height: 8, borderRadius: '50%', background: s.color }} />
                      {s.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Priority picker */}
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setPrioOpen(o => !o)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '6px 12px', borderRadius: 'var(--r-sm)',
                  background: 'var(--surface-3)', border: '1px solid var(--border)',
                  color: 'var(--text-primary)', cursor: 'pointer', fontSize: 12,
                }}
              >
                Priority <ChevronDown size={13} />
              </button>
              {priorityOpen && (
                <div style={{
                  position: 'absolute', top: '110%', left: 0, zIndex: 10,
                  background: 'var(--surface-2)', border: '1px solid var(--border)',
                  borderRadius: 'var(--r-md)', overflow: 'hidden', minWidth: 120,
                  boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
                }}>
                  {Object.entries(BRAND.priorities).map(([key, cfg]) => (
                    <button
                      key={key}
                      onClick={() => handlePriorityChange(key)}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 8,
                        width: '100%', padding: '8px 12px',
                        background: task.priority === key ? 'var(--violet-dim)' : 'none',
                        border: 'none', cursor: 'pointer',
                        color: cfg.color, fontSize: 12, fontWeight: 700, textAlign: 'left',
                      }}
                    >
                      {cfg.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Bounce buttons */}
            <button
              onClick={() => handleBounce('internal')}
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                padding: '6px 12px', borderRadius: 'var(--r-sm)',
                background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)',
                color: 'var(--s-bounced)', cursor: 'pointer', fontSize: 12,
              }}
            >
              <RotateCcw size={12} /> Bounce Internal
            </button>
            <button
              onClick={() => handleBounce('client')}
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                padding: '6px 12px', borderRadius: 'var(--r-sm)',
                background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)',
                color: 'var(--s-bounced)', cursor: 'pointer', fontSize: 12,
              }}
            >
              <RotateCcw size={12} /> Bounce Client
            </button>
          </div>

          {/* Details grid */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 1fr',
            gap: '14px 20px',
            padding: 16,
            background: 'var(--surface-2)',
            borderRadius: 'var(--r-md)',
            border: '1px solid var(--border)',
          }}>
            <Field label="Brief">{task.brief_title ?? '—'}</Field>
            <Field label="Client">{task.client_name ?? '—'}</Field>
            <Field label="Campaign">{task.campaign_name ?? '—'}</Field>
            <Field label="AM">{task.am_name ?? '—'}</Field>
            <Field label="Internal Deadline">{fmt(task.internal_deadline)}</Field>
            <Field label="Launch Date">{fmt(task.launch_date)}</Field>
            {task.shoot_date && <Field label="Shoot Date">{fmt(task.shoot_date)}</Field>}
            <Field label="Revisions">
              <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)' }}>
                INT: {task.internal_revision_count ?? 0} · CLT: {task.client_revision_count ?? 0}
              </span>
            </Field>
          </div>

          {/* Comments */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <MessageCircle size={14} color="var(--text-muted)" />
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-muted)' }}>
                Comments
              </span>
            </div>

            {loadingComments ? (
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>Loading…</p>
            ) : comments.length === 0 ? (
              <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>No comments yet</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {comments.map(c => (
                  <div key={c.id} style={{ display: 'flex', gap: 10 }}>
                    <Avatar
                      name={c.author?.full_name}
                      initials={c.author?.initials}
                      color={c.author?.avatar_color}
                      size={28}
                    />
                    <div style={{
                      flex: 1, background: 'var(--surface-3)',
                      borderRadius: 'var(--r-md)', padding: '8px 12px',
                    }}>
                      <div style={{ display: 'flex', gap: 8, marginBottom: 4, alignItems: 'baseline' }}>
                        <span style={{ fontSize: 12, fontWeight: 600 }}>{c.author?.full_name}</span>
                        <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>
                          {new Date(c.created_at).toLocaleString('en-GB', {
                            day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'
                          })}
                        </span>
                      </div>
                      <p style={{ fontSize: 13, lineHeight: 1.5 }}>{c.body}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Comment input */}
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
              <textarea
                value={newComment}
                onChange={e => setNewComment(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submitComment() }
                }}
                placeholder="Add a comment… (Enter to post, Shift+Enter for newline)"
                rows={2}
                style={{
                  flex: 1, resize: 'none',
                  background: 'var(--surface-3)', border: '1px solid var(--border)',
                  borderRadius: 'var(--r-md)', padding: '8px 12px',
                  color: 'var(--text-primary)', fontSize: 13,
                  fontFamily: 'var(--font-ui)',
                  outline: 'none',
                }}
              />
              <button
                onClick={submitComment}
                disabled={saving || !newComment.trim()}
                style={{
                  padding: 10, borderRadius: 'var(--r-md)',
                  background: 'var(--violet)', border: 'none',
                  cursor: 'pointer', color: '#fff',
                  display: 'flex', alignItems: 'center',
                  opacity: saving || !newComment.trim() ? 0.5 : 1,
                }}
              >
                <Send size={15} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default TaskDrawer
