import { useState } from 'react'
import TaskCard from './TaskCard'
import BRAND from '../config/brand'

export function KanbanBoard({ tasks, onTaskClick, onMoveTask }) {
  const [dragging, setDragging] = useState(null)
  const [dragOver, setDragOver] = useState(null)

  const tasksByStage = stage => tasks.filter(t => t.stage === stage)

  const handleDragStart = (e, task) => {
    setDragging(task)
    e.dataTransfer.effectAllowed = 'move'
  }

  const handleDragOver = (e, stageId) => {
    e.preventDefault()
    setDragOver(stageId)
    e.dataTransfer.dropEffect = 'move'
  }

  const handleDrop = (e, stageId) => {
    e.preventDefault()
    if (dragging && dragging.stage !== stageId) {
      onMoveTask(dragging.id, stageId)
    }
    setDragging(null)
    setDragOver(null)
  }

  const handleDragEnd = () => {
    setDragging(null)
    setDragOver(null)
  }

  return (
    <div style={{
      display: 'flex',
      gap: 10,
      padding: '16px 20px',
      overflowX: 'auto',
      height: '100%',
      alignItems: 'flex-start',
    }}>
      {BRAND.stages.map(stage => {
        const cards  = tasksByStage(stage.id)
        const isDim  = stage.dim
        const isOver = dragOver === stage.id

        return (
          <div
            key={stage.id}
            style={{
              flexShrink: 0,
              width: 230,
              display: 'flex',
              flexDirection: 'column',
              gap: 0,
              opacity: isDim ? 0.5 : 1,
            }}
            onDragOver={e => handleDragOver(e, stage.id)}
            onDrop={e => handleDrop(e, stage.id)}
            onDragLeave={() => setDragOver(null)}
          >
            {/* Column header */}
            <div style={{
              padding: '8px 10px',
              borderRadius: 'var(--r-md) var(--r-md) 0 0',
              background: isOver ? `${stage.color}15` : 'var(--surface-1)',
              border: `1px solid ${isOver ? stage.color + '50' : 'var(--border)'}`,
              borderBottom: 'none',
              display: 'flex', alignItems: 'center', gap: 8,
              transition: 'background 0.15s, border-color 0.15s',
            }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: stage.color, flexShrink: 0 }} />
              <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', flex: 1 }}>
                {stage.label}
              </span>
              <span style={{
                fontSize: 11, fontFamily: 'var(--font-mono)',
                color: 'var(--text-muted)', background: 'var(--surface-3)',
                padding: '1px 6px', borderRadius: 99,
              }}>
                {cards.length}
              </span>
            </div>

            {/* Cards container */}
            <div style={{
              minHeight: 120,
              border: `1px solid ${isOver ? stage.color + '50' : 'var(--border)'}`,
              borderTop: 'none',
              borderRadius: '0 0 var(--r-md) var(--r-md)',
              background: isOver ? `${stage.color}08` : 'var(--surface-1)',
              padding: 8,
              display: 'flex',
              flexDirection: 'column',
              gap: 8,
              transition: 'background 0.15s, border-color 0.15s',
            }}>
              {cards.map(task => (
                <div
                  key={task.id}
                  draggable
                  onDragStart={e => handleDragStart(e, task)}
                  onDragEnd={handleDragEnd}
                  style={{
                    opacity: dragging?.id === task.id ? 0.4 : 1,
                    transition: 'opacity 0.15s',
                  }}
                >
                  <TaskCard task={task} onClick={() => onTaskClick(task)} />
                </div>
              ))}

              {cards.length === 0 && !isOver && (
                <div style={{
                  padding: '20px 0', textAlign: 'center',
                  color: 'var(--text-muted)', fontSize: 12,
                }}>
                  —
                </div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default KanbanBoard
