import { useState, useEffect } from 'react'
import supabase from './lib/supabase'
import { fetchEmployees } from './lib/queries'
import Sidebar from './components/Sidebar'
import Board from './pages/Board'
import MyTasks from './pages/MyTasks'
import Briefs from './pages/Briefs'
import Clients from './pages/Clients'
import Team from './pages/Team'
import BRAND from './config/brand'

// ── Top bar ──────────────────────────────────────────────────
function TopBar({ page }) {
  const labels = { board: 'Board', list: 'My Tasks', briefs: 'Briefs', clients: 'Clients', team: 'Team' }
  return (
    <div style={{
      height: 50, flexShrink: 0,
      background: 'var(--surface-1)',
      borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center',
      padding: '0 20px',
    }}>
      <h2 style={{ fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>
        {labels[page] ?? page}
      </h2>
    </div>
  )
}

// ── Login screen ─────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState('')
  const [pass, setPass]   = useState('')
  const [err, setErr]     = useState(null)
  const [loading, setL]   = useState(false)

  const submit = async e => {
    e.preventDefault()
    setL(true); setErr(null)
    const { error } = await supabase.auth.signInWithPassword({ email, password: pass })
    if (error) { setErr(error.message); setL(false) }
  }

  const inputStyle = {
    width: '100%', padding: '10px 12px',
    background: 'var(--surface-2)', border: '1px solid var(--border)',
    borderRadius: 'var(--r-md)', color: 'var(--text-primary)',
    fontSize: 14, fontFamily: 'var(--font-ui)', outline: 'none',
  }

  return (
    <div style={{
      height: '100%', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: 'var(--page)',
    }}>
      <form onSubmit={submit} style={{
        width: 360, display: 'flex', flexDirection: 'column', gap: 16,
        padding: 32,
        background: 'var(--surface-1)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--r-xl)',
      }}>
        <div style={{ textAlign: 'center', marginBottom: 8 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 12,
            background: 'var(--violet)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, fontWeight: 800, color: '#fff',
            margin: '0 auto 12px',
          }}>
            {BRAND.logoText}
          </div>
          <h1 style={{ fontSize: 18, fontWeight: 700 }}>{BRAND.appName}</h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>Sign in to continue</p>
        </div>

        <input
          type="email" placeholder="Email" required
          value={email} onChange={e => setEmail(e.target.value)}
          style={inputStyle}
        />
        <input
          type="password" placeholder="Password" required
          value={pass} onChange={e => setPass(e.target.value)}
          style={inputStyle}
        />

        {err && <p style={{ color: 'var(--p1)', fontSize: 12 }}>{err}</p>}

        <button
          type="submit"
          disabled={loading}
          style={{
            padding: '10px', borderRadius: 'var(--r-md)',
            background: 'var(--violet)', border: 'none',
            color: '#fff', fontWeight: 700, fontSize: 14,
            cursor: 'pointer', opacity: loading ? 0.6 : 1,
          }}
        >
          {loading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </div>
  )
}

// ── App root ─────────────────────────────────────────────────
export default function App() {
  const [session, setSession]         = useState(null)
  const [currentUser, setCurrentUser] = useState(null)
  const [page, setPage]               = useState('board')
  const [authReady, setAuthReady]     = useState(false)

  // Auth listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setAuthReady(true)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, s) => {
      setSession(s)
    })
    return () => subscription.unsubscribe()
  }, [])

  // Load employee profile when logged in
  useEffect(() => {
    if (!session?.user) { setCurrentUser(null); return }
    fetchEmployees().then(employees => {
      const me = employees.find(e => e.email === session.user.email)
      setCurrentUser(me ?? null)
    })
  }, [session?.user?.id])

  if (!authReady) return (
    <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: 'var(--text-muted)', fontSize: 14 }}>
      Loading…
    </div>
  )

  if (!session) return <LoginScreen onLogin={setSession} />

  const pages = { board: Board, list: MyTasks, briefs: Briefs, clients: Clients, team: Team }
  const Page = pages[page] ?? Board

  return (
    <div style={{ display: 'flex', height: '100%' }}>
      <Sidebar activePage={page} onNav={setPage} currentUser={currentUser} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <TopBar page={page} />
        <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <Page currentUser={currentUser} />
        </div>
      </div>
    </div>
  )
}
