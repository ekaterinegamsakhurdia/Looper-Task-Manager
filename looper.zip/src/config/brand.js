// ============================================================
// LOOPER TASKS — BRAND CONFIG
// Edit this file to customise colours, labels, and org settings.
// ============================================================

export const BRAND = {
  // ── App identity ──────────────────────────────────────────
  appName:    'Looper Tasks',
  orgName:    'Looper Agency',
  slug:       'looper-tasks',       // used for localStorage keys
  logoText:   'LT',                 // shown in sidebar when no logo

  // ── Palette (mirrors brand.css tokens) ───────────────────
  colors: {
    page:       '#050B18',
    surface1:   '#0D1425',
    surface2:   '#131B2E',
    surface3:   '#1A2340',
    border:     '#1E2A40',
    borderMid:  '#253050',
    textPrimary:'#E8EDF5',
    textSecond: '#8B9BB8',
    textMuted:  '#4A5A82',
    violet:     '#7C5CFC',
    violetDim:  'rgba(124,92,252,0.15)',
  },

  // ── Priority colours ──────────────────────────────────────
  priorities: {
    P1: { label: 'P1', color: '#F85C5C', bg: 'rgba(248,92,92,0.15)' },
    P2: { label: 'P2', color: '#F4A32A', bg: 'rgba(244,163,42,0.15)' },
    P3: { label: 'P3', color: '#4FC4CF', bg: 'rgba(79,196,207,0.15)' },
    P4: { label: 'P4', color: '#4A5A82', bg: 'rgba(74,90,130,0.15)' },
  },

  // ── Department colours ────────────────────────────────────
  departments: {
    Design:     { label: 'Design',     color: '#A78BFA' },
    Production: { label: 'Production', color: '#34D399' },
    DM:         { label: 'DM',         color: '#60A5FA' },
    Copy:       { label: 'Copy',       color: '#F472B6' },
  },

  // ── Kanban stages (12 real Notion stages) ────────────────
  stages: [
    { id: 'Not started',      label: 'Not Started',      color: '#6B7280', cssClass: 'stage-notstarted',    dim: false },
    { id: 'Editing',          label: 'Editing',           color: '#3B82F6', cssClass: 'stage-editing',       dim: false },
    { id: 'Motion',           label: 'Motion',            color: '#6366F1', cssClass: 'stage-motion',        dim: false },
    { id: 'Designing',        label: 'Designing',         color: '#8B5CF6', cssClass: 'stage-designing',     dim: false },
    { id: 'Bounced',          label: 'Bounced',           color: '#EF4444', cssClass: 'stage-bounced',       dim: false },
    { id: 'Internal Review',  label: 'Internal Review',   color: '#F59E0B', cssClass: 'stage-internalrev',   dim: false },
    { id: 'Sent to client',   label: 'Sent to Client',    color: '#06B6D4', cssClass: 'stage-senttoclient',  dim: false },
    { id: 'Approved',         label: 'Approved',          color: '#10B981', cssClass: 'stage-approved',      dim: false },
    { id: 'Delivered',        label: 'Delivered',         color: '#22C55E', cssClass: 'stage-delivered',     dim: false },
    { id: 'Archive',          label: 'Archive',           color: '#4ADE80', cssClass: 'stage-archive',       dim: false },
    { id: 'Shoot Readiness',  label: 'Shoot Readiness',   color: '#94A3B8', cssClass: 'stage-shootready',    dim: true  },
    { id: 'Filming',          label: 'Filming',           color: '#94A3B8', cssClass: 'stage-filming',       dim: true  },
  ],

  // ── Task types ────────────────────────────────────────────
  taskTypes: ['Video','Post/Design','Story','Reel','Animation','Copy','Photo','OOH','Print'],

  // ── Brief types / statuses ────────────────────────────────
  briefTypes:    ['Video','Post/Design','Story','Campaign'],
  briefStatuses: ['Copy','Design','Production','Done','Archived'],

  // ── Client tiers ─────────────────────────────────────────
  clientTiers: {
    Gold:   { label: 'Gold',   color: '#F59E0B' },
    Silver: { label: 'Silver', color: '#94A3B8' },
    Bronze: { label: 'Bronze', color: '#CD7C2F' },
  },

  // ── Employee roles ────────────────────────────────────────
  roles: ['AM','Designer','Videographer','Copywriter','Editor','Social Manager','Director','Admin'],
}

export default BRAND
